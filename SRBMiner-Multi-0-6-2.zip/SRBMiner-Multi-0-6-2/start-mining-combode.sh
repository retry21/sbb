#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm phi5 --pool stratum-eu.rplant.xyz:7055 --wallet combode-wallet-here
